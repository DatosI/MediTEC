package fire.resource;


import java.util.LinkedList;
import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.codehaus.jettison.json.JSONException;

import com.ibm.json.java.JSONObject;

import arboles.ArbolBB;

@Path("/service/")
public class Service {
   
   
   	@GET
	@Produces("application/json")
	public Response Doctor() throws JSONException {

		JSONObject jsonObject = new JSONObject();
		ListaDoctores listadoc = new ListaDoctores();
		Doctor Emer= new Doctor(1,"Emer");
		Doctor Joel= new Doctor(2,"Joel");
		Doctor Melanie= new Doctor(3,"Melanie");
		Doctor Andrea= new Doctor(4,"Andrea");
		
		listadoc.Insertar(Emer);
		listadoc.Insertar(Joel);
		listadoc.Insertar(Melanie);
		listadoc.Insertar(Andrea);
		
		
		jsonObject.put("Altura del 'Arbol", 1); 
		

		String result = "@Produces(\"application/json\") Output: \n\n    Doctores: \n\n" + jsonObject;
		return Response.status(200).entity(result).build();
	  }

	  @Path("{n}") 
	  @GET
	  @Produces("application/json")
	  public Response DoctorfromInput(@PathParam("n") String n) throws JSONException {

		JSONObject jsonObject = new JSONObject();
		ArbolBB doctores = new ArbolBB();
		doctores.insertar("Emer");
		doctores.insertar("Melanie");
		doctores.insertar("Omar");
		doctores.insertar("Andrea");
		doctores.insertar("Saul");
		String nombre= doctores.buscar(n).raiz;
		
		 
		jsonObject.put("N Value", nombre); 
		
		

		String result = "@Produces(\"application/json\") Output: \n\n doctores: \n\n" + jsonObject;
		return Response.status(200).entity(result).build();
	  }
}