package fire.resource;

public class CasosClinicos {
	

}
