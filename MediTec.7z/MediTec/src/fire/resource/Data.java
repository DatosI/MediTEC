package fire.resource;

public class Data {
	private int value;
	private int a;
	private String b;
	
	
	public Data(int a,String b){
	this.a=a;
	this.b=b;
	
	}
	
	public void setA(int c){
		this.a = c;
	}
	public void setB(String d){
		this.b= d;
	}
	
	public int getA(){
		return a;
	}
	
	public String getB(){
		return b;
	}
		  
}
