package fire.resource;

import arboles.ArbolBB;
import arboles.Arbol_Splay;

public class Doctor {
	public String nombre;
	public int id;
	ArbolBB listacitas;
	Arbol_Splay doctor;
	
	
	
	
	
	public Doctor(int id, String nombre) {
		super();
		this.id=id;
		this.nombre = nombre;
	}
	
	
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public ArbolBB getListacitas() {
		return listacitas;
	}
	public void setListacitas(ArbolBB listacitas) {
		this.listacitas = listacitas;
	}
	
	
	
	
	

}
