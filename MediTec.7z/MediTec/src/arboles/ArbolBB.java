package arboles;

import java.util.Vector;


public class ArbolBB {
    public String  raiz;
    
    Vector<String> miVector = new Vector<String>();
    ArbolBB subABizq;
    ArbolBB subABder;


    public ArbolBB() {
        raiz = "";
        subABizq = null;
        subABder = null;
    }

  
    public ArbolBB( String raiz ) {
       this.raiz = ( raiz ); 
        subABizq = null;
        subABder = null;
    }
  
    
    
    private boolean esVacio() {
        boolean vacio = true;

        if ( raiz != ""){
            vacio = false;
        }
        return vacio;
    }
    


    
    public void insertar(String  nuevo ) {
        if( esVacio() ) {
            raiz = ( nuevo );
            subABizq = new ArbolBB();
            subABder = new ArbolBB();
        } else {
            if (nuevo.compareTo(raiz)<0){
               subABizq.insertar(nuevo);
            }else if (nuevo.compareTo(raiz)>0) {
                subABder.insertar(nuevo);
            }
        }
    }
  
    
    
    public ArbolBB buscar( String x ) {
    	ArbolBB buscado = null;
        try{
            if (!esVacio()) {
                if( x.compareTo(raiz)<0 ) {
                    buscado = subABizq.buscar(x);
                } else if ( x.compareTo(raiz)>0 ) {
                    buscado = subABder.buscar(x);
                } else {
                    return this;
                }
            } 
            return buscado;
        }
        catch (Exception e) {
            buscado=null;
            System.out.println("no existe");
            return buscado;
        }
    }
    
    

    public ArbolBB buscarMax() {
    	ArbolBB arbolActual = this;

        while( !arbolActual.subABder.esVacio() ) {
            arbolActual = arbolActual.subABder;
        }
        
        return arbolActual;
    }
    


    public ArbolBB buscarMin() {
    	ArbolBB arbolActual = this;

        while( !arbolActual.subABizq.esVacio() ) {
            arbolActual = arbolActual.subABizq;
        }
       
        return arbolActual;
    }
   
    
    private boolean esHoja() {
        boolean hoja = false;

        if( subABizq.esVacio() && subABder.esVacio() ) {
            hoja = true;
        }

        return hoja;
    }
    
    
    
    public int altura() {
        if (esVacio()) {
            return -1;
        }
        
        else {
            return (1 + Math.max(subABizq.altura(),subABder.altura()));
        }
        
    } 
    


     public void eliminar(String a ) {
    	 ArbolBB aEliminar = buscar(a);

        if (aEliminar != null) {
            if( aEliminar.esHoja() ) {
                aEliminar.raiz = "";
            } else {
            	ArbolBB  min =  aEliminar.subABder.buscarMin();
                aEliminar.raiz = min.raiz;
                min.eliminar(min.raiz);
            }
        }
    }


    public void PreOrden() {
        if( !esVacio() ) {
            System.out.println( raiz );
            subABizq.PreOrden();
            subABder.PreOrden();
        }
    }

    public void InOrden() {
        if( !esVacio() ) {
            subABizq.InOrden();
            System.out.println( raiz );
            subABder.InOrden();
        }
    }

    public void PosOrden() {
        if( !esVacio() ) {
            subABizq.PosOrden();
            subABder.PosOrden();
            System.out.println( raiz );
        }
    }


    public void porNivel() {
        Vector<ArbolBB> cola = new Vector<ArbolBB>();
        ArbolBB arbol;

        cola.add(this);
        while( !cola.isEmpty() ) {
            arbol = cola.elementAt(0);
            cola.remove(0);
            System.out.println( arbol.raiz );
            if ( !arbol.subABizq.esVacio() ) cola.add( arbol.subABizq );
            if (!arbol.subABder.esVacio() ) cola.add( arbol.subABder );
        }
    }
    
    
    
    
    
}
