package Main;

import Nodo.Doctor;
import Nodo.ListaDoctores;
import Árboles.ArbolAVL;
import Árboles.Arbol_AVL;
import Árboles.Arbol_B;
import Árboles.Arbol_BB;
import Árboles.Arbol_Binario_de_Busqueda;
import Árboles.Arbol_BB;
import Árboles.Arbol_Splay_S;
import Árboles.Arbol_Splay;




public class Main {
    public static void main(String[] args){
        Arbol_BB arbol1 = new Arbol_BB();
        Arbol_AVL arbol = new Arbol_AVL();
        Arbol_Splay_S arbol2= new  Arbol_Splay_S();
        
        Arbol_Splay nuevo=new Arbol_Splay();
        ArbolAVL NUEVO=new ArbolAVL();
        
        Arbol_B arbol3= new Arbol_B();
        
        
        ListaDoctores listadoc = new ListaDoctores();
        Doctor Emer= new Doctor(1,"Emer");
	Doctor Joel= new Doctor(2,"Joel");
	Doctor Melanie= new Doctor(3,"Melanie");
	Doctor Andrea= new Doctor(4,"Andrea");
        
       // listadoc.Insertar(Emer);
          
        
        arbol3.Inserta(6);
        arbol3.Inserta(11);
        arbol3.Inserta(5);
        arbol3.Inserta(4);
        arbol3.Inserta(8);
        arbol3.Inserta(9);
        arbol3.Inserta(12);
        arbol3.Inserta(21);
        arbol3.Inserta(14);
        arbol3.Inserta(10);
        arbol3.Inserta(19);
        arbol3.Inserta(28);
        arbol3.Inserta(3);
        arbol3.Inserta(17);
        arbol3.Inserta(32);
        arbol3.Inserta(15);
        arbol3.Inserta(16);
        arbol3.Inserta(26);
        arbol3.Inserta(27);
        arbol3.Inserta(12);
        //arbol3.Eliminar(Melanie);
        /*
        Arbol_BB e= new Arbol_BB();
        
        e.insertar("Andres");
        e.insertar("Andrea");
        e.insertar("Saul");
        e.insertar("Adrian");
        e.insertar("Andy");
        e.insertar("Alex");
        e.insertar("Adan");
        e.buscar1("Ad", e );
        System.out.println(e.buscar1("An",e).size());
       
     */   
    }
     
}
