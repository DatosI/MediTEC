package Listas;

import Nodo.Nodo;







public class Lista_Doblemente_Enlazada {
    private Nodo Head;
    private Nodo Last;
    private int Size;

    public Lista_Doblemente_Enlazada() {
        this.Head = null;
        this.Last = null;
        this.Size = 0;
    }
    
    
    public boolean isEmpty(){
        return Head==Last ;
    }
    
    public int getSize() {
        return Size;
    }
    
    
    
    
    public void InsertFirst(int dato) {
        Nodo NewNode= new Nodo();
        NewNode.setDato(dato); 
        if (this.isEmpty()) {
            this.Head=this.Last=NewNode;
        } else {
            NewNode.setNext(this.Head);
            this.Head=NewNode;
        }
        this.Size ++;
    }     
    
       
    public void InsertLast(int dato) {
        Nodo NewNode= new Nodo();
        NewNode.setDato(dato); 
        if (this.isEmpty()) {
            this.Head=this.Last=NewNode;
        } else {
            Nodo aux=this.Last;
            aux.setNext(NewNode);
            this.Last=NewNode;
        }
        this.Size ++;
    }     

    
    
    
}


