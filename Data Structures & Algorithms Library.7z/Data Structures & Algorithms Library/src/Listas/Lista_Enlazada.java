package Listas;

import Nodo.Nodo;






public class Lista_Enlazada {
     private Nodo Head;
    private int Size;

    public Lista_Enlazada () {
        this.Head = null;
        this.Size = 0;
    }
    
    
    public boolean isEmpty(){
        return Head==null;
    }

    public int getSize() {
        return Size;
    }
    
    
    public void InsertLast(int dato){
        Nodo NewNode= new Nodo();
        NewNode.setDato(dato);
        if (isEmpty()){
            Head=NewNode;
        }else{
            Nodo aux = Head;
            while(aux.getNext()!= null){
                aux= aux.getNext();
            }
            aux.setNext(NewNode);
        }
        Size++;  
    }
    
    public void InsertFirst(int dato){
        Nodo NewNode= new Nodo();
        NewNode.setDato(dato);
        if (isEmpty()){
            Head=NewNode;
        }else{
            NewNode.setNext(Head);
            Head=NewNode;
        }
        Size++;  
    }
      
}
