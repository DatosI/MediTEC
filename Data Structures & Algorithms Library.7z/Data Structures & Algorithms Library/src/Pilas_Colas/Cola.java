package Pilas_Colas;






public class Cola {
   
    private int maxSize;
    private int front;
    private int rear;
    private int size;
    private Object elements[];
    
    public Cola(int maxSize){
        this.elements = new Object[maxSize];
        this.front = 0;
        this.rear = -1;
        this.size = 0;
        this.maxSize = maxSize;
}
    public void encolar(Object element){
        if (this.size==this.maxSize){
            System.out.println("La cola esta llena");
            return;
        }
        this.rear = (this.rear + 1) % this.maxSize;
        this.elements[rear] = element;
        this.size++;
    }
    
    
    public Object desencolar(){
        if(this.size==0){
            System.out.println("La cola desta vacia");
            return null;
        }
        Object temp = this.elements[front];
        front = (front + 1) % this.maxSize;
        this.size--;
        return temp;
    } 
    
}

    

